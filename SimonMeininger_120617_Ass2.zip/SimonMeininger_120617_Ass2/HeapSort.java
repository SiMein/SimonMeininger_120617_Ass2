package de.assignment2;

public class HeapSort {
	
	static int total;	// for arraysizeinformation

	

	static void sort(Comparable[] arr) {  // sort-function get the array(tree) 
		total=arr.length-1;			// get the size of the tree/array	
		for (int i = total; i>=0;i--) { // first thing -before sorting, make sure that the complete array is a heap
			heapify(arr, i);
		}
		for( int i=total;i>0;i--) { // swap first elements with i�th element and dekrement 
			swap(arr,0,i);	// finished when "i" reached the first element (nothing more to swap)
			total--;
			heapify(arr, 0);	//make sure thet it is a heap again for the next round
		}
	}
	
	static void swap(Comparable[] arr, int a, int b) { // swaps the the elements on position a and b in the array
		Comparable temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}
	

	static void heapify(Comparable[] arr, int i) { // Comparable-array for sorting different Types of Data 
											// can use Standardtypes but from the Wrapperclasses ! 		
		int left = i*2;		// using the mathematical definition for heap for jump to the the treelevels/ nodes
		int right = i*2+1;
		int help =i;
		if (left<= total && arr[left].compareTo(arr[help])>=0) { //needs to be in range of the three/array and
			help=left;						//compareTo works like a minus
		}								//so when a child node is >=, it will be markered for swapping
		if (right<= total && arr[right].compareTo(arr[help])>=0) {
			help=right;						// same here--this will case first executed, because overriding
		}
		if(help!=i) {		//stops when when left and right was in the correct order 
			swap(arr,i,help);	// swaps i and help
			heapify(arr, help);	//	check again if its a heap
		}
	}
	
	
	
	public static void main(String[] args) {
		
		// create different Typs of arrays with different sizes, proof the function by print out their elements 
		
		Byte[] arrEmpty= {};
		System.out.println("\n\nBefor Sort empty");
		for(int i= 0; i<arrEmpty.length;i++) {
			System.out.print(arrEmpty[i]+"; ");
		}
		sort(arrEmpty);
		System.out.println("\nAfter Sort empty");
		for(int i= 0; i<arrEmpty.length;i++) {
			System.out.print(arrEmpty[i]+"; ");
		}	
		
		
		
		Double[] arrOneElem= {2.0};
		System.out.println("\n\nBefor Sort only one elem");
		for(int i= 0; i<arrOneElem.length;i++) {
			System.out.print(arrOneElem[i]+"; ");
		}
		sort(arrOneElem);
		System.out.println("\nAfter Sort only one elem");
		for(int i= 0; i<arrOneElem.length;i++) {
			System.out.print(arrOneElem[i]+"; ");
		}	
	
		
		
		Integer[] arr= {22,88,-33,0,11,0};
		System.out.println("\n\nBefor Sort");
		for(int i= 0; i<arr.length;i++) {
			System.out.print(arr[i]+"; ");
		}
		sort(arr);
		System.out.println("\nAfter Sort");
		for(int i= 0; i<arr.length;i++) {
			System.out.print(arr[i]+"; ");
		}
	}	
}
